<?php
return array(
	'garbagecollector:period' => '¿Con qué frecuencia se debe ejecutar el recolector de basura Elgg? ',

	'garbagecollector:weekly' => 'Semanalmente',
	'garbagecollector:monthly' => 'Mensualmente',
	'garbagecollector:yearly' => 'Anualmente',

	'garbagecollector' => "RECOLECTOR DE BASURA\n",
	'garbagecollector:done' => "HECHO\n",
	'garbagecollector:optimize' => "Optimizando %s ",

	'garbagecollector:error' => "ERROR",
	'garbagecollector:ok' => "OK",

	'garbagecollector:gc:metastrings' => 'Limpiando metastrings desvinculados: ',
);
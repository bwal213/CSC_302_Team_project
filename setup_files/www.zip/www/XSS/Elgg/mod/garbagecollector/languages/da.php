<?php
return array(
	'garbagecollector:period' => 'Hvor ofte skal Elgg opsamle skrald?',

	'garbagecollector:weekly' => 'En gang om ugen',
	'garbagecollector:monthly' => 'En gang om måneden',
	'garbagecollector:yearly' => 'En gang om året',

	'garbagecollector' => "SKRALD OPSAMLER\n",
	'garbagecollector:done' => "FÆRDIG\n",
	'garbagecollector:optimize' => "Optimerer %s ",

	'garbagecollector:error' => "FEJL",
	'garbagecollector:ok' => "OK",

	'garbagecollector:gc:metastrings' => 'Rydder op i uforbundne metastrenge: ',
);
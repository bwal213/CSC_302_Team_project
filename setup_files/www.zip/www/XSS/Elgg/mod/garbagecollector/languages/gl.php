<?php
return array(
	'garbagecollector:period' => 'Con que frecuencia debería executarse o recolledor do lixo de Elgg?',

	'garbagecollector:weekly' => 'Cada semana',
	'garbagecollector:monthly' => 'Cada mes',
	'garbagecollector:yearly' => 'Cada an',

	'garbagecollector' => "Recolledor do lixo\n",
	'garbagecollector:done' => "Listo\n",
	'garbagecollector:optimize' => "Optimizando %s…",

	'garbagecollector:error' => "Erro",
	'garbagecollector:ok' => "Si",

	'garbagecollector:gc:metastrings' => 'Limpando cadeas de metadatos desligadas:',
);
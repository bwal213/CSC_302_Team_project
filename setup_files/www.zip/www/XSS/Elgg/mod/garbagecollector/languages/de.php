<?php
return array(
	'garbagecollector:period' => 'Wie oft soll der Garbage Collector ausgeführt werden?',

	'garbagecollector:weekly' => 'Einmal pro Woche',
	'garbagecollector:monthly' => 'Einmal pro Monat',
	'garbagecollector:yearly' => 'Einmal pro Jahr',

	'garbagecollector' => "GARBAGE COLLECTOR\n",
	'garbagecollector:done' => "FERTIG\n",
	'garbagecollector:optimize' => "Optimiere %s ",

	'garbagecollector:error' => "FEHLER",
	'garbagecollector:ok' => "OK",

	'garbagecollector:gc:metastrings' => 'Entfernen nicht-verlinkter Metastrings: ',
);
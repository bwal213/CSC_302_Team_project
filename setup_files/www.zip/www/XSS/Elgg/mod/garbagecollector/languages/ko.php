<?php
return array(
	'garbagecollector:period' => 'Elgg 쓰레기 처리기를 얼마나 자주 실행할까요?',

	'garbagecollector:weekly' => '매주',
	'garbagecollector:monthly' => '매월',
	'garbagecollector:yearly' => '매년',

	'garbagecollector' => "쓰레기 처리기\n",
	'garbagecollector:done' => "완료\n",
	'garbagecollector:optimize' => "최적화중 %s ",

	'garbagecollector:error' => "오류",
	'garbagecollector:ok' => "좋음",

	'garbagecollector:gc:metastrings' => '연결되지 않은 중간문자열을 삭제하는 중입니다.',
);
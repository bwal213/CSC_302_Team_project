<?php
return array(
	'garbagecollector:period' => 'Hoe vaak wil je dat Elgg de garbage collector draait?',

	'garbagecollector:weekly' => 'Eens per week',
	'garbagecollector:monthly' => 'Eens per maand',
	'garbagecollector:yearly' => 'Eens per jaar',

	'garbagecollector' => "GARBAGE COLLECTOR\n",
	'garbagecollector:done' => "KLAAR\n",
	'garbagecollector:optimize' => "Optimaliseren %s ",

	'garbagecollector:error' => "FOUT",
	'garbagecollector:ok' => "OK",

	'garbagecollector:gc:metastrings' => 'Opruimen van niet-gelinkte metastrings:',
);
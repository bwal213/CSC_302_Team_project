<?php
return array(
	'garbagecollector:period' => 'Quanto spesso Elgg dovrebbe raccogliere ed eliminare la "spazzatura"?',

	'garbagecollector:weekly' => 'Una volta alla settimana',
	'garbagecollector:monthly' => 'Una volta al mese',
	'garbagecollector:yearly' => 'Una volta all\'anno',

	'garbagecollector' => "RACCOGLITORE SPAZZATURA\n",
	'garbagecollector:done' => "FATTO\n",
	'garbagecollector:optimize' => "Ottimizzando %s",

	'garbagecollector:error' => "ERRORE",
	'garbagecollector:ok' => "OK",

	'garbagecollector:gc:metastrings' => 'Pulendo metastring non linkate:',
);
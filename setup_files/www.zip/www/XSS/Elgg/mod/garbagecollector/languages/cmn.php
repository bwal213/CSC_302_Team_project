<?php
return array(
	'garbagecollector:period' => 'Elgg 記憶空間回收器應該要多久運行一次？',

	'garbagecollector:weekly' => '一週一次',
	'garbagecollector:monthly' => '一月一次',
	'garbagecollector:yearly' => '一年一次',

	'garbagecollector' => "記憶空間回收器\n",
	'garbagecollector:done' => "完成\n",
	'garbagecollector:optimize' => "最佳化 %s ",

	'garbagecollector:error' => "錯誤",
	'garbagecollector:ok' => "確定",

	'garbagecollector:gc:metastrings' => '清理掉未鏈結的中繼字串：',
);
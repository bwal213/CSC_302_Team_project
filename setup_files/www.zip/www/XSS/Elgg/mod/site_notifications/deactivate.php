<?php
/**
 * Deregister the class
 */

update_subtype('object', 'site_notification');

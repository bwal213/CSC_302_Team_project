Web Services
============

This plugin provides the web services API that was packaged with Elgg core from
version 1.0-1.8. Other plugins can expose functions as web services for 
integration with other platforms or applications.

Documentation is available at [http://learn.elgg.org](http://learn.elgg.org/en/stable/guides/web-services.html)

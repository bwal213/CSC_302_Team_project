<?php
/**
 * Deregister the ElggDiscussionReply class
 */

update_subtype('object', 'discussion_reply');
<?php

return [
	'default' => [
		'ckeditor.js' => __DIR__ . '/vendors/ckeditor/ckeditor.js',
		'ckeditor/' => __DIR__ . '/vendors/ckeditor/',
		'jquery.ckeditor.js' => __DIR__ . '/vendors/ckeditor/adapters/jquery.js',
	],
];

<?php
return array(
	'legacy_urls:message' => 'Ta strona została przeniesiona pod adres %s. Proszę zaktualizować odnośnik lub zgłosić niepoprawny.',

	'legacy_urls:instructions' => 'Wybierz politykę obsługi przestarzałych URLi',
	'legacy_urls:immediate' => 'Natychmiast przekieruj do nowego URLa',
	'legacy_urls:immediate_error' => 'Natychmiast przekieruj do nowego URLa i wyświetl komunikat błędu',
	'legacy_urls:landing' => 'Wyświetl stronę z odnośnikiem do nowego URLa',
);

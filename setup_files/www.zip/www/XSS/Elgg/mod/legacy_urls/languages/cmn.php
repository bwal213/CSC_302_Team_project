<?php
return array(
	'legacy_urls:message' => 'This page has moved to %s. Please update your bookmark or report the link that led here.',

	'legacy_urls:instructions' => 'Select method for handling legacy URLs',
	'legacy_urls:immediate' => 'Immediately forward to the new URL',
	'legacy_urls:immediate_error' => 'Immediately forward to the new URL and display an error message',
	'legacy_urls:landing' => 'Display a page with a link to the the new URL',
);

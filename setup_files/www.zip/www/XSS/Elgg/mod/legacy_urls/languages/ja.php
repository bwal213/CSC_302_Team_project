<?php
return array(
	'legacy_urls:message' => 'このページは %s に移動しました。 あなたのブックマークを更新するかリンクを報告してください。',

	'legacy_urls:instructions' => 'レガシーURLsの取り扱い方法を選択してください。',
	'legacy_urls:immediate' => '新しいURLへ直ちにフォワードする',
	'legacy_urls:immediate_error' => '新しいURLへ直ちにフォワードしてエラーメッセージを表示する',
	'legacy_urls:landing' => '新しいURLへのリンクを記載したページを表示する',
);

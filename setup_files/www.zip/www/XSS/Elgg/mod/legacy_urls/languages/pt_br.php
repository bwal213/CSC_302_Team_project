<?php
return array(
	'legacy_urls:message' => 'Esta página foi removida para %s. Por favor, atualize seus favoritos ou informar o link que o direcionou até aqui.',

	'legacy_urls:instructions' => 'Escolha um método para lidar com URLs legados (legacy URLs)',
	'legacy_urls:immediate' => 'Redirecione imediatamente à nova URL',
	'legacy_urls:immediate_error' => 'Redirecione imediatamente à nova URL e apresente uma mensagem de erro',
	'legacy_urls:landing' => 'Apresente uma página com um link para o novo URL',
);

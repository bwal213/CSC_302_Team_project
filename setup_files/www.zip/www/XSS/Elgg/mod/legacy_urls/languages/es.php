<?php
return array(
	'legacy_urls:message' => 'Esta página ha sido movida a %s. Por favor actualiza tu marcador o reporta el link que te llevo aquí.',

	'legacy_urls:instructions' => 'Selecciona un método para manejar URLs antiguas',
	'legacy_urls:immediate' => 'Inmediatamente redireccionar al nuevo URL',
	'legacy_urls:immediate_error' => 'Inmediatamente redireccionar al nuevo URL y mostrar un mensaje de error',
	'legacy_urls:landing' => 'Mostrar una página con un link al nuevo URL',
);

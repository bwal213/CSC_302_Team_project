<?php
return array(
	'legacy_urls:message' => '이 페이지는 %s 로 이동되었습니다. 책갈피를 갱신하거나 이곳으로 연결된 링크를 신고해주세요.',

	'legacy_urls:instructions' => '기본 주소를 다룰 방법을 선택하세요',
	'legacy_urls:immediate' => '새 주소로 바로 보냄',
	'legacy_urls:immediate_error' => '새 주소로 바로 보내고 오류 표시',
	'legacy_urls:landing' => '새 주소로의 링크와 페이지를 표시',
);

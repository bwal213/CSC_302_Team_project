<?php
return array(
	'legacy_urls:message' => 'Pagina spostata su %s. Per favore aggiorna i tuoi segnalibri oppure facci sapere qual è il link che ti ha portato qui, grazie.',

	'legacy_urls:instructions' => 'Seleziona il metodo per gestire i link ereditati',
	'legacy_urls:immediate' => 'Inoltra immediatamente al nuovo indirizzo',
	'legacy_urls:immediate_error' => 'Inoltra immediatamente al nuovo indirizzo e visualizza un messaggio di errore',
	'legacy_urls:landing' => 'Visualizza una pagina con un link al nuovo indirizzo',
);

<?php
return array(
	'legacy_urls:message' => 'Deze pagina is verplaatst naar %s. Pas je favoriet/bladwijzer aan! Je kunt ook de link waar je vandaan kwam melden.',

	'legacy_urls:instructions' => 'Selecteer de methode hoe je verkeerde URL\'s wilt behandelen:',
	'legacy_urls:immediate' => 'Stuur direct door naar de nieuwe URL',
	'legacy_urls:immediate_error' => 'Stuur direct door naar de nieuwe URL en toon een foutmelding',
	'legacy_urls:landing' => 'Toon een pagina met de link naar de nieuwe URL',
);

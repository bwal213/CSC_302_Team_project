<?php
return array(
	'legacy_urls:message' => 'Cette page a été déplacée vers %s. Veuillez SVP mettre à jour votre signet et nous signaler le lien qui vous a conduit ici.',

	'legacy_urls:instructions' => 'Sélectionnez une méthode pour la gestion des URL pré-existantes',
	'legacy_urls:immediate' => 'Transférer immédiatement vers la nouvelle URL',
	'legacy_urls:immediate_error' => 'Transférer immédiatement vers la nouvelle URL et afficher un message d\'erreur',
	'legacy_urls:landing' => 'Afficher une page avec un lien vers la nouvelle URL',
);

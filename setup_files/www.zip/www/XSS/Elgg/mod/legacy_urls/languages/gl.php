<?php
return array(
	'legacy_urls:message' => 'A páxina moveuse a %s. Actualice o seu marcador ou informe de que a ligazón que o levou ata aquí está obsoleta.',

	'legacy_urls:instructions' => 'Seleccione o método co que xestionar os enderezos URL obsoletos.',
	'legacy_urls:immediate' => 'Redirixir inmediatamente ao novo URL',
	'legacy_urls:immediate_error' => 'Redirixir inmediatamente ao novo URL e mostrar unha mensaxe de erro',
	'legacy_urls:landing' => 'Mostrar unha páxina cunha ligazón ao novo URL',
);

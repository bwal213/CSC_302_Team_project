<?php
return array(
	'legacy_urls:message' => 'Orri hau %s-ra mugitua izan da. Mesedez eguneratu zure laster-marka edo ohartarazi hona ekarri zaituen esteka.',

	'legacy_urls:instructions' => 'URL legatuak maneiatzeko metodo bat aukeratu',
	'legacy_urls:immediate' => 'URL berrira zuzenean bidali',
	'legacy_urls:immediate_error' => 'URL berrira zuzenean bidali eta errore mezua erakutsi',
	'legacy_urls:landing' => 'URL berrirako orrialdea estekarekin erakutsi',
);

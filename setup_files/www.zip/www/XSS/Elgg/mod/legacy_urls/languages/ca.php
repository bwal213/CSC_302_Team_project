<?php
return array(
	'legacy_urls:message' => 'Aquesta pàgina s\'ha mogut a %s. Actualitzeu la vostra adreça d\'interès o informeu sobre l\'enllaç que us ha portat fins aquí.',

	'legacy_urls:instructions' => 'Selecciona un mètode per utilitzar les URLs preexistents',
	'legacy_urls:immediate' => 'Ves immediatament a la nova URL',
	'legacy_urls:immediate_error' => 'Ves immediatament a la nova URL i mostra un missatge d\'error',
	'legacy_urls:landing' => 'Mostra una pàgina amb l\'enllaç a la nova URL',
);

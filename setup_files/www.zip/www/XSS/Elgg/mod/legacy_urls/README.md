Legacy URL Support
===================
As Elgg has been developed, the URLs for pages have changed.

Elgg 1.8
----------
Beginning all pages with the 'pg' prefix was deprecated.

Elgg 1.5
----------
The tag pages were replaced by search

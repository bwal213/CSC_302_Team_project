<?php
return [
	'default' => [
		'pages/' => __DIR__ . '/images',
	],
];

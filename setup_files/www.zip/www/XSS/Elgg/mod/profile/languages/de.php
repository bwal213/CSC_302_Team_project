<?php
return array(
	'profile' => 'Profil',
	'profile:notfound' => 'Entschuldigung, wir konnten das gesuchte Profil nicht finden.',

);
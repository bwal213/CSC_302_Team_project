<?php
return array(
	'profile' => 'Profil',
	'profile:notfound' => 'Przepraszamy. Nie można znaleźć określonego profilu.',

);
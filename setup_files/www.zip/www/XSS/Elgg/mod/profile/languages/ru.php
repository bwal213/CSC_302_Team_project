<?php
return array(
	'profile' => 'Профиль',
	'profile:notfound' => 'Извините, не удается найти указанный профиль.',

);
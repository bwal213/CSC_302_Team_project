<?php
return array(
	'profile' => 'Profil',
	'profile:notfound' => 'Désolé, nous n\'avons pas pu trouver le profil demandé.',

);
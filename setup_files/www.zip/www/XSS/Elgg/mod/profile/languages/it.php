<?php
return array(
	'profile' => 'Profilo',
	'profile:notfound' => 'Spiacenti ma è impossibile trovare il profilo richiesto.',

);
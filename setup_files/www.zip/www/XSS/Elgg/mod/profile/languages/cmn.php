<?php
return array(
	'profile' => '側寫',
	'profile:notfound' => '抱歉。我們找不到要求的側寫。',

);
<?php
return array(
	'profile' => '신상',
	'profile:notfound' => '미안합니다. 요청된 신상정보를 찾을 수 없었습니다.',

);
<?php
return array(
	'profile' => 'Profiili',
	'profile:notfound' => 'Hakemaasi profiilia ei löytynyt.',

);
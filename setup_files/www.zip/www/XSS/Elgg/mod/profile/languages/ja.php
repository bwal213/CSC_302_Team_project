<?php
return array(
	'profile' => 'プロフィール',
	'profile:notfound' => '申し訳ありません、お探しのプロフィールを見つけることができませんでした。',

);
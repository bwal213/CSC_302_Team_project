<?php
return array(
	'profile' => 'Perfil',
	'profile:notfound' => 'No se puede encontrar el perfil solicitado.',

);
<?php
return array(
	'profile' => 'Perfil',
	'profile:notfound' => 'Ep!, no trobem aquest perfil',

);
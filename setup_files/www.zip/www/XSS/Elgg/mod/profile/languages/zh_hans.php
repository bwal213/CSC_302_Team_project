<?php
return array(
	'profile' => '简历',
	'profile:notfound' => '抱歉，未找到该简历。',

);
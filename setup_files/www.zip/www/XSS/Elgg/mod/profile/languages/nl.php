<?php
return array(
	'profile' => 'Profiel',
	'profile:notfound' => 'Sorry. Het opgegeven profiel kon niet gevonden worden.',

);
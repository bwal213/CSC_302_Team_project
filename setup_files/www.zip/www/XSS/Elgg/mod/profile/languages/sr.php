<?php
return array(
	'profile' => 'Профил',
	'profile:notfound' => 'Извините. Нисмо успели да пронађемо профил.',

);
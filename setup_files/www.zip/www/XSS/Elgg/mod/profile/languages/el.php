<?php
return array(
	'profile' => 'Προφίλ',
	'profile:notfound' => 'Δεν βρέθηκε το προφίλ που ζητήσατε.',

);
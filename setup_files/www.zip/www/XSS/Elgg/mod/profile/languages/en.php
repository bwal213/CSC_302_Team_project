<?php
return array(
	'profile' => 'Profile',
	'profile:notfound' => 'Sorry. We could not find the requested profile.',

);
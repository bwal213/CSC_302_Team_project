<?php
return array(
	'profile' => 'Perfil',
	'profile:notfound' => 'Desculpe. Não foi possível encontrar o perfil especificado.',

);
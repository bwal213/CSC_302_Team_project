<?php
return array(
	'profile' => 'Profil',
	'profile:notfound' => 'Üzgünüz. İstediğiniz profili bulamadık.',

);
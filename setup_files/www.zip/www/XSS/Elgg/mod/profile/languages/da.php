<?php
return array(
	'profile' => 'Profil',
	'profile:notfound' => 'Beklager, vi kunne ikke finde den ønskede profil.',

);
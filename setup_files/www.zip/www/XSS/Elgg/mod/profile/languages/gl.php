<?php
return array(
	'profile' => 'Perfi',
	'profile:notfound' => 'Non foi posíbel atopar o perfil indicado.',

);
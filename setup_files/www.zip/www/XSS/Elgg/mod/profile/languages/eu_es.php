<?php
return array(
	'profile' => 'Profila',
	'profile:notfound' => 'Barkatu. Ezin dugu bilatu eskatzen ari zaren profila.',

);
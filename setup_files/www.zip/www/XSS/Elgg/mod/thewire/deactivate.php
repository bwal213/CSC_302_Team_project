<?php
/**
 * Deregister the ElggWire class
 */

update_subtype('object', 'thewire');
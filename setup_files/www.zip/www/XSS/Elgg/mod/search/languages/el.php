<?php

return array(
	'search:enter_term' => 'Εισάγετε μια φράση για αναζήτηση:',
	'search:no_results' => 'Δεν υπάρχουν αποτελέσματα.',
	'search:matched' => 'Matched:',
	'search:results' => 'Αποτελέσματα για %s',
	'search:no_query' => 'Εισάγετε μια φράση για αναζήτηση.',
	'search:search_error' => 'Σφάλμα',

	'search:more' => '+%s περισσότερα %s',

	'search_types:tags' => 'Ετικέτες',

	'search_types:comments' => 'Σχόλια',
	'search:comment_on' => 'Σχόλιο σε "%s"',
	'search:comment_by' => 'από',
	'search:unavailable_entity' => 'Μη Διαθέσιμη Οντότητα',
	'search:unknown_entity' => 'Μη διαθέσιμος τύπος οντότητας',
);

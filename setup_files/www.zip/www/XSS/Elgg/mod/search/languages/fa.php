<?php

return array(
	'search:enter_term' => 'یک واژه برای جستجو وارد کنید:',
	'search:no_results' => 'بدون نتیجه.',
	'search:matched' => 'همسان:',
	'search:results' => 'نمایش نتایج برای %s',
	'search:no_query' => 'لطفا یک کلمه برای جستجو وارد کنید.',
	'search:search_error' => 'خطا',

	'search:more' => '+%s بیشتر %s',

	'search_types:tags' => 'برچسب ها',

	'search_types:comments' => 'نظر',
	'search:comment_on' => 'نظر در "%s"',
	'search:comment_by' => 'توسط',
	'search:unavailable_entity' => 'نهاد در دسترس نیست',
	'search:unknown_entity' => 'نوع نهاد ناشناخته',
);

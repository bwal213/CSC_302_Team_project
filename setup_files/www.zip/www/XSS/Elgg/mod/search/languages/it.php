<?php

return array(
	'search:enter_term' => 'Inserisci il testo da cercare:',
	'search:no_results' => 'Nessun risultato.',
	'search:matched' => 'Corrispondenze:',
	'search:results' => 'Risultati per %s',
	'search:no_query' => 'Per favore inserisci il testo da cercare.',
	'search:search_error' => 'Errore',

	'search:more' => '+%s più %s',

	'search_types:tags' => 'Tag',

	'search_types:comments' => 'Commenti',
	'search:comment_on' => 'Commento su "%s"',
	'search:comment_by' => 'di',
	'search:unavailable_entity' => 'Elemento non disponibile',
	'search:unknown_entity' => 'Tipo di elemento sconosciuto',
);

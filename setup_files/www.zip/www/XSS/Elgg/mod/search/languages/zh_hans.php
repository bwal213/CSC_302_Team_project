<?php

return array(
	'search:enter_term' => '输入搜索词',
	'search:no_results' => '没有结果。',
	'search:matched' => '匹配：',
	'search:results' => '%s 的结果',
	'search:no_query' => '请输入搜索请求。',
	'search:search_error' => '错误',

	'search:more' => '+%s 更多 %s',

	'search_types:tags' => '标签',

	'search_types:comments' => '评论',
	'search:comment_on' => '关于“%s”的评论',
	'search:comment_by' => 'by',
	'search:unavailable_entity' => '不可用实体',
	'search:unknown_entity' => '未知的实体类型',
);

<?php

return array(
	'search:enter_term' => 'Wpisz słowo kluczowe:',
	'search:no_results' => 'Brak wyników.',
	'search:matched' => 'Dopasowano:',
	'search:results' => 'Wyniki dla %s',
	'search:no_query' => 'Proszę podać zapytanie, aby wyszukać.',
	'search:search_error' => 'Błąd',

	'search:more' => '+%s więcej %s',

	'search_types:tags' => 'Tagi',

	'search_types:comments' => 'Komentarze',
	'search:comment_on' => 'Komentarze dotyczące "%s"',
	'search:comment_by' => 'przez',
	'search:unavailable_entity' => 'Niedostępna encja',
	'search:unknown_entity' => 'Nieznany typ encji',
);

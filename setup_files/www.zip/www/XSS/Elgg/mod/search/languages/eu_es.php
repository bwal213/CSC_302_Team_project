<?php

return array(
	'search:enter_term' => 'Sartu bilaketaren terminoa:',
	'search:no_results' => 'Ez dago emaitzarik.',
	'search:matched' => 'Bilatuta:',
	'search:results' => '%s-ren emaitzak',
	'search:no_query' => 'Mesedez, bilatzeko kontsulta bat sartu.',
	'search:search_error' => 'Errorea',

	'search:more' => '+%s gehiago %s',

	'search_types:tags' => 'Etiketak',

	'search_types:comments' => 'Iruzkinak',
	'search:comment_on' => 'Iruzkinak "%s"-en',
	'search:comment_by' => 'nork',
	'search:unavailable_entity' => 'Entitate erabilezina',
	'search:unknown_entity' => 'Entitate mota ezezaguna',
);

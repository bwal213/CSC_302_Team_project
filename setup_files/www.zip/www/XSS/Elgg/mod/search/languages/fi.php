<?php

return array(
	'search:enter_term' => 'Syötä hakusana:',
	'search:no_results' => 'Ei hakutuloksia.',
	'search:matched' => 'Matched: ',
	'search:results' => 'Tulokset haulle %s',
	'search:no_query' => 'Et syöttänyt hakusanaa.',
	'search:search_error' => 'Virhe',

	'search:more' => 'Näytä lisää hakutuloksia (%skpl)',

	'search_types:tags' => 'Tagit',

	'search_types:comments' => 'Kommentit',
	'search:comment_on' => 'Kommentti kohteelle "%s"',
	'search:comment_by' => 'käyttäjältä',
	'search:unavailable_entity' => 'Kohde, jota ei saatavilla',
	'search:unknown_entity' => 'Tuntematon kohdetyyppi',
);

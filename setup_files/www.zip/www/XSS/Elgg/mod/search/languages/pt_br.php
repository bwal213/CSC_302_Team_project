<?php

return array(
	'search:enter_term' => 'Insira um termo de busca:',
	'search:no_results' => 'Nenhum resultado encontrado.',
	'search:matched' => 'Encontrado:',
	'search:results' => 'Resultados para %s',
	'search:no_query' => 'Por favor insira uma consulta para procurar.',
	'search:search_error' => 'Erro',

	'search:more' => '+%s mais %s',

	'search_types:tags' => 'Tags',

	'search_types:comments' => 'Comentários',
	'search:comment_on' => 'Comentário em "%s"',
	'search:comment_by' => 'por',
	'search:unavailable_entity' => 'Entidade indisponível',
	'search:unknown_entity' => 'Tipo de entidade desconhecida',
);

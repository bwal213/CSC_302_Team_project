<?php

return array(
	'search:enter_term' => 'Escriba un temo de busca:',
	'search:no_results' => 'Non hai resultados',
	'search:matched' => 'Coincidencias:',
	'search:results' => 'Resultados para %s',
	'search:no_query' => 'Escriba unha consulta para buscar',
	'search:search_error' => 'Erro',

	'search:more' => '+%s %s máis',

	'search_types:tags' => 'Etiquetas',

	'search_types:comments' => 'Comentarios',
	'search:comment_on' => 'Comentario en «%s»',
	'search:comment_by' => 'de',
	'search:unavailable_entity' => 'Entidade non dispoñíbel',
	'search:unknown_entity' => 'Tipo de entidade descoñecido',
);

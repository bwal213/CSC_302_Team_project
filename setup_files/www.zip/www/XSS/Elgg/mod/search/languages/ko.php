<?php

return array(
	'search:enter_term' => '검색할 말을 입력하세요:',
	'search:no_results' => '결과가 없습니다.',
	'search:matched' => '찾음:',
	'search:results' => '%s 에 대한 결과',
	'search:no_query' => '검색할 문구를 입력하세요.',
	'search:search_error' => '오류',

	'search:more' => '+%s 더 %s',

	'search_types:tags' => '꼬리표',

	'search_types:comments' => '댓글',
	'search:comment_on' => '"%s" 에 대한 답글',
	'search:comment_by' => '의',
	'search:unavailable_entity' => '없는 항목',
	'search:unknown_entity' => '알수없는 항목 종류',
);

<?php

return array(
	'search:enter_term' => 'Introduzca un término de búsqueda:',
	'search:no_results' => 'Sin resultados.',
	'search:matched' => 'Coincide: ',
	'search:results' => 'Resultados para %s',
	'search:no_query' => 'Por favor ingresa una consulta para buscar.',
	'search:search_error' => 'Error',

	'search:more' => '+%s m&aacute;s %s',

	'search_types:tags' => 'Tags',

	'search_types:comments' => 'Comments',
	'search:comment_on' => 'Comment on "%s"',
	'search:comment_by' => 'por',
	'search:unavailable_entity' => 'Entrada no disponible',
	'search:unknown_entity' => 'Tipo de Entidad Desconocida',
);

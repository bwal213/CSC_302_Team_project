<?php
return array(
	'logrotate:period' => 'Quanto di frequente devono essere archiviati i log di sistema?',

	'logrotate:logrotated' => "Log ruotati\n",
	'logrotate:lognotrotated' => "Errore durante la rotazione del log\n",
	
	'logrotate:delete' => 'Elimina i logs archiviati prima del',

	'logrotate:week' => 'settimana',
	'logrotate:month' => 'mese',
	'logrotate:year' => 'anno',
	'logrotate:never' => 'mai',
		
	'logrotate:logdeleted' => "Log eliminato\n",
	'logrotate:lognotdeleted' => "Nessun log eliminato\n",
);

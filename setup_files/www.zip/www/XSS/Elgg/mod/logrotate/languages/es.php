<?php
return array(
	'logrotate:period' => '&iquest;Qu&eacute; frecuencioa deseas para rotar los registros?',

	'logrotate:logrotated' => "Registro rotado\n",
	'logrotate:lognotrotated' => "Error al rotar los registros\n",
	
	'logrotate:delete' => 'Borrar los registros archivados anteriores a',

	'logrotate:week' => 'una semana',
	'logrotate:month' => 'un mes',
	'logrotate:year' => 'un año',
	'logrotate:never' => 'nunca',
		
	'logrotate:logdeleted' => "Registro borrado\n",
	'logrotate:lognotdeleted' => "Ningún log fue eliminado",
);

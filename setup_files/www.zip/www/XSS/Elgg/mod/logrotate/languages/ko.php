<?php
return array(
	'logrotate:period' => '얼마나 자주 시스템 로그를 보관하겠습니까?',

	'logrotate:logrotated' => "로그 순환됨\n",
	'logrotate:lognotrotated' => "로그 순환 오류\n",
	
	'logrotate:delete' => '보다 오래된 보관된 로그를 삭제함',

	'logrotate:week' => '주',
	'logrotate:month' => '달',
	'logrotate:year' => '년',
	'logrotate:never' => '안함',
		
	'logrotate:logdeleted' => "로그 삭제됨\n",
	'logrotate:lognotdeleted' => "삭제된 로그가 없슴\n",
);

<?php
return array(
	'logrotate:period' => 'A quelle fréquence souhaitez-vous archiver les logs du système ?',

	'logrotate:logrotated' => "Rotation du log effectuée\n",
	'logrotate:lognotrotated' => "Erreur lors de la rotation du log\n",
	
	'logrotate:delete' => 'Supprimer les journaux archivés plus anciens qu\'',

	'logrotate:week' => 'une semaine',
	'logrotate:month' => 'un mois',
	'logrotate:year' => 'une année',
	'logrotate:never' => 'plus récents',
		
	'logrotate:logdeleted' => "Fichier journal (fichier log) supprimé\n",
	'logrotate:lognotdeleted' => "Aucun fichier journal (fichier log) n'a été supprimé\n",
);

<?php
return array(
	'logrotate:period' => 'Как часто архивировать лог?',

	'logrotate:logrotated' => "Лог прокручен\n",
	'logrotate:lognotrotated' => "Ошибка прокрутки\n",
	
	'logrotate:delete' => 'Удалять архив логов старше чем',

	'logrotate:week' => 'неделя',
	'logrotate:month' => 'месяц',
	'logrotate:year' => 'год',
	'logrotate:never' => 'никогда',
		
	'logrotate:logdeleted' => "Журнал удален\n",
	'logrotate:lognotdeleted' => "Ошибка при удалении\n",
);

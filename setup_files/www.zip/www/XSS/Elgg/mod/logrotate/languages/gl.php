<?php
return array(
	'logrotate:period' => 'Con que frecuencia debe arquivarse o rexistro do sistema?',

	'logrotate:logrotated' => "Rotouse o rexistro\n",
	'logrotate:lognotrotated' => "Non foi posíbel rotar o rexistro.\n",
	
	'logrotate:delete' => 'Eliminar rexistros arquivados de máis de',

	'logrotate:week' => 'unha semana',
	'logrotate:month' => 'un mes',
	'logrotate:year' => 'un an',
	'logrotate:never' => 'nunca',
		
	'logrotate:logdeleted' => "Eliminouse o rexistro.\n",
	'logrotate:lognotdeleted' => "Non se eliminou ningún rexistro.\n",
);

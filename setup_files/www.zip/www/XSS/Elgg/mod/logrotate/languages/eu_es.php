<?php
return array(
	'logrotate:period' => 'Zenbat bider nahi duzu sistemaren loga artxibatua izatea?',

	'logrotate:logrotated' => "Loga biratuta\n",
	'logrotate:lognotrotated' => "Errorea loga biratzean\n",
	
	'logrotate:delete' => 'Hau baino zaharragoak diren ezabatutako log artxibatuak',

	'logrotate:week' => 'astea',
	'logrotate:month' => 'hilabetea',
	'logrotate:year' => 'urtea',
	'logrotate:never' => 'inoiz',
		
	'logrotate:logdeleted' => "Ezabatutako loga\n",
	'logrotate:lognotdeleted' => "Ez dago ezabatutako logik\n",
);

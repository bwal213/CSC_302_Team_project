<?php
return array(
	'logrotate:period' => 'Hoe vaak moet het systeemlogboek worden gearchiveerd?',

	'logrotate:logrotated' => "Logboek gearchiveerd",
	'logrotate:lognotrotated' => "Fout tijdens het archiveren van het logboek",
	
	'logrotate:delete' => 'Verwijder logboekarchieven ouder dan een',

	'logrotate:week' => 'week',
	'logrotate:month' => 'maand',
	'logrotate:year' => 'jaar',
	'logrotate:never' => 'nooit',
		
	'logrotate:logdeleted' => "Log verwijderd
",
	'logrotate:lognotdeleted' => "Fout tijdens het verwijderen van de log",
);

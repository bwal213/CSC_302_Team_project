<?php
return array(
	'logrotate:period' => 'Com que frequência deve o sistema arquivar o \'log\' ?',

	'logrotate:logrotated' => "Log arquivado
",
	'logrotate:lognotrotated' => "Erro ao arquivar o log
",
	
	'logrotate:delete' => 'Apague os arquivos de registros mais antigos que',

	'logrotate:week' => 'semana',
	'logrotate:month' => 'mês',
	'logrotate:year' => 'ano',
	'logrotate:never' => 'nunca',
		
	'logrotate:logdeleted' => "Log apagado",
	'logrotate:lognotdeleted' => "Erro ao apagar o log",
);

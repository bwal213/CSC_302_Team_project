<?php
return array(
	'logrotate:period' => 'Jak często logi systemowe powinny być archiwizowane?',

	'logrotate:logrotated' => "Rotacja logów",
	'logrotate:lognotrotated' => "Błąd rotacji logów",
	
	'logrotate:delete' => 'Usuń zarchiwizowane pliki rejestrowe starsze niż',

	'logrotate:week' => 'tydzień',
	'logrotate:month' => 'miesiąc',
	'logrotate:year' => 'rok',
	'logrotate:never' => 'nigdy',
		
	'logrotate:logdeleted' => "Plik rejestrowy usunięty\n",
	'logrotate:lognotdeleted' => "Nie usunięto żadnych logów\n",
);

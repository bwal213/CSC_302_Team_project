<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Pagine del sito",
	'admin:appearance:expages' => "Pagine del sito",
	'expages:edit:viewpage' => "Visualizza la pagina dal sito",
	'expages:about' => "Informazioni",
	'expages:terms' => "Termini",
	'expages:privacy' => "Privacy",
	'expages:contact' => "Contatto",

	'expages:notset' => "Questa pagina non è stata ancora impostata.",

	/**
	 * Status messages
	 */
	'expages:posted' => "La tua pagina è stata aggiornata con successo.",
	'expages:error' => "Non è possibile salvare questa pagina.",
);
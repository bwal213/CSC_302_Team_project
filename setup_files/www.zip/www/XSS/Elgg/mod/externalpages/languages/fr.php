<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Pages externes",
	'admin:appearance:expages' => "Pages externes",
	'expages:edit:viewpage' => "Voir la page sur le site",
	'expages:about' => "À propos",
	'expages:terms' => "Mentions légales",
	'expages:privacy' => "Informations personnelles",
	'expages:contact' => "Contact",

	'expages:notset' => "Cette page n'a pas été définie pour le moment.",

	/**
	 * Status messages
	 */
	'expages:posted' => "La page externe a bien été mise à jour.",
	'expages:error' => "Impossible d'enregistrer cette page.",
);
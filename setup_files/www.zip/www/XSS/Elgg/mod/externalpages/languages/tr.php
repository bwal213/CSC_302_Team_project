<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Site sayfaları",
	'admin:appearance:expages' => "Site Sayfaları",
	'expages:about' => "Hakkında",
	'expages:terms' => "Kullanım Koşulları",
	'expages:privacy' => "Gizlilik",
	'expages:contact' => "İletişim",

	'expages:notset' => "Bu sayfa henüz oluşturulmadı.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Sayfa başarılı şekilde kaydedildi.",
	'expages:error' => "Bu sayfa kaydedilemiyor.",
);
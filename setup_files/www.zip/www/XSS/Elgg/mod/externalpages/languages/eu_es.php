<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Guneko orrialdeak",
	'admin:appearance:expages' => "Guneko orrialdeak",
	'expages:edit:viewpage' => "Orrialdea gunean ikusi",
	'expages:about' => "Honi buruz",
	'expages:terms' => "Baldintzak",
	'expages:privacy' => "Pribatutasuna",
	'expages:contact' => "Kontaktua",

	'expages:notset' => "Orrialdea hau oraindik ez da konfiguratu.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Zure orrialdea arrakastaz eguneratu da.",
	'expages:error' => "Ezinezkoa da orrialdea gordetzea.",
);
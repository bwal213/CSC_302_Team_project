<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Externe pagina's",
	'admin:appearance:expages' => "Externe pagina's",
	'expages:edit:viewpage' => "Bekijk pagina op de site",
	'expages:about' => "Over ons",
	'expages:terms' => "Algemene voorwaarden",
	'expages:privacy' => "Privacy",
	'expages:contact' => "Contact",

	'expages:notset' => "Deze pagina is nog niet beschikbaar.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Je pagina is succesvol bijgewerkt.",
	'expages:error' => "De pagina kon niet worden opgeslagen.",
);
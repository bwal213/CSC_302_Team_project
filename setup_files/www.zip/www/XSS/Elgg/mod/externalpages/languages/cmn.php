<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "站臺頁面",
	'admin:appearance:expages' => "站臺頁面",
	'expages:about' => "關於",
	'expages:terms' => "條款",
	'expages:privacy' => "隱私",
	'expages:contact' => "聯絡",

	'expages:notset' => "尚未設置這個頁面。",

	/**
	 * Status messages
	 */
	'expages:posted' => "您的頁面已成功更新。",
	'expages:error' => "無法儲存這個頁面。",
);
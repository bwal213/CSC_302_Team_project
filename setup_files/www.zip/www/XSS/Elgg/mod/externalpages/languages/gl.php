<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Páxinas do siti",
	'admin:appearance:expages' => "Páxinas do sitio",
	'expages:edit:viewpage' => "Ver a páxina no sitio",
	'expages:about' => "Información",
	'expages:terms' => "Condicións",
	'expages:privacy' => "Intimidade",
	'expages:contact' => "Contact",

	'expages:notset' => "Esta páxina aínda non está configurada.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Actualizouse a páxina.",
	'expages:error' => "Non é posíbel gardar a páxina.",
);
<?php
return array(

	/**
	 * Menu items and titles
	 */
	'expages' => "Внешние страницы",
	'admin:appearance:expages' => "Страницы сайта",
	'expages:about' => "О сайте",
	'expages:terms' => "Правила",
	'expages:privacy' => "Конфиденциальность",
	'expages:contact' => "Контакты",

	'expages:notset' => "Эта страница пока недоступна.",

	/**
	 * Status messages
	 */
	'expages:posted' => "Страница успешно сохранена.",
	'expages:error' => "Ошибка при сохранении.",
);
<?php
return array(
	'tagcloud:widget:title' => 'Облако тегов',
	'tagcloud:widget:description' => 'Облако тегов',
	'tagcloud:widget:numtags' => 'Количество тегов показывать',
	'tagcloud:site_cloud' => 'Облако тегов сайта',
	'tagcloud:allsitetags' => 'Все теги сайта',
);

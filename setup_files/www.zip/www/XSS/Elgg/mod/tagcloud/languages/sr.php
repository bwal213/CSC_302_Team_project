<?php
return array(
	'tagcloud:widget:title' => 'Облак ознака',
	'tagcloud:widget:description' => 'Облак ознака',
	'tagcloud:widget:numtags' => 'Број ознака за приказ',
	'tagcloud:site_cloud' => 'Облак ознака целог сајта',
	'tagcloud:allsitetags' => 'Све ознаке сајта',
);

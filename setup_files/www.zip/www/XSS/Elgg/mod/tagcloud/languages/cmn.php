<?php
return array(
	'tagcloud:widget:title' => '標籤雲',
	'tagcloud:widget:description' => '標籤雲',
	'tagcloud:widget:numtags' => '要顯示的標籤數量',
	'tagcloud:site_cloud' => '站臺標籤雲',
	'tagcloud:allsitetags' => '全站標籤',
);

<?php
return array(
	'tagcloud:widget:title' => 'Etiketen hodeia',
	'tagcloud:widget:description' => 'Etiketen hodeia',
	'tagcloud:widget:numtags' => 'Erakutsiko diren etiketa kopurua',
	'tagcloud:site_cloud' => 'Guneko etiketa hodeia',
	'tagcloud:allsitetags' => 'Guneko etiketa guztiak',
);

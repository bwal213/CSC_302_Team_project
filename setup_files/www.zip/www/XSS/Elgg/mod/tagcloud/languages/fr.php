<?php
return array(
	'tagcloud:widget:title' => 'Nuage de Tags',
	'tagcloud:widget:description' => 'Nuage de tags',
	'tagcloud:widget:numtags' => 'Nombre de tags à afficher',
	'tagcloud:site_cloud' => 'Nuage de tag du site',
	'tagcloud:allsitetags' => 'Tous les tags du site',
);

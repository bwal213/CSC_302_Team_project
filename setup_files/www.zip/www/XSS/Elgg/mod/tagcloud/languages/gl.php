<?php
return array(
	'tagcloud:widget:title' => 'Nube de etiquetas',
	'tagcloud:widget:description' => 'Nube de etiquetas',
	'tagcloud:widget:numtags' => 'Número de etiquetas para mostrar',
	'tagcloud:site_cloud' => 'Nube de etiquetas global',
	'tagcloud:allsitetags' => 'Etiquetas globais',
);

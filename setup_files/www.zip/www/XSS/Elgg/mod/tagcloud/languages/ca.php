<?php
return array(
	'tagcloud:widget:title' => 'Núvol d\'etiquetes',
	'tagcloud:widget:description' => 'Núvol d\'etiquetes',
	'tagcloud:widget:numtags' => 'Nombre d\'etiquetes a mostrar',
	'tagcloud:site_cloud' => 'Núvol d\'etiquetes',
	'tagcloud:allsitetags' => 'Totes les etiquetes',
);

<?php
return array(
	'tagcloud:widget:title' => 'Tag Cloud',
	'tagcloud:widget:description' => 'Tag cloud',
	'tagcloud:widget:numtags' => 'Antal tags, der skal vises',
	'tagcloud:site_cloud' => 'Site Tag Cloud',
	'tagcloud:allsitetags' => 'Alle tags',
);

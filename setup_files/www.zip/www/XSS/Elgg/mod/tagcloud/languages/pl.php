<?php
return array(
	'tagcloud:widget:title' => 'Chmura tagów',
	'tagcloud:widget:description' => 'Chmura tagów',
	'tagcloud:widget:numtags' => 'Ilość wyświetlanych tagów',
	'tagcloud:site_cloud' => 'Chmura tagów strony',
	'tagcloud:allsitetags' => 'Wszystkie tagi',
);

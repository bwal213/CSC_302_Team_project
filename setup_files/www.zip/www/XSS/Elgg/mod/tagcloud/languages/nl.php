<?php
return array(
	'tagcloud:widget:title' => 'Tagcloud',
	'tagcloud:widget:description' => 'Tag cloud',
	'tagcloud:widget:numtags' => 'Aantal tags om weer te geven',
	'tagcloud:site_cloud' => 'Site tag-cloud',
	'tagcloud:allsitetags' => 'Alle site-tags',
);

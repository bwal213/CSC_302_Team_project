<?php
return array(
	'tagcloud:widget:title' => 'Tagcloud',
	'tagcloud:widget:description' => 'Tagcloud',
	'tagcloud:widget:numtags' => 'Anzahl der anzuzeigenden Tags.',
	'tagcloud:site_cloud' => 'Tagcloud',
	'tagcloud:allsitetags' => 'Alle Tags der Seite',
);

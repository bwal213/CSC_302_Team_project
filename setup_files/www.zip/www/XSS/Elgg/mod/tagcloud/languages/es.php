<?php
return array(
	'tagcloud:widget:title' => 'Nube de etiquetas',
	'tagcloud:widget:description' => 'Nube de etiquetas',
	'tagcloud:widget:numtags' => 'N&uacute;mero de etiquetas a mostrar',
	'tagcloud:site_cloud' => 'Nube de Tags del Sitio',
	'tagcloud:allsitetags' => 'Tags de todo el sitio',
);

<?php
return array(
	'tagcloud:widget:title' => 'Tagipilvi',
	'tagcloud:widget:description' => 'Tagipilvi',
	'tagcloud:widget:numtags' => 'Näytettävien kohteiden määrä',
	'tagcloud:site_cloud' => 'Tagipilvi',
	'tagcloud:allsitetags' => 'Kaikki sivuston tagit',
);

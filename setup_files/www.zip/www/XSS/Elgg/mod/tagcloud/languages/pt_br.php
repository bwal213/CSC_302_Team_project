<?php
return array(
	'tagcloud:widget:title' => 'Nuvem de palavras',
	'tagcloud:widget:description' => 'Nuvem de palavras',
	'tagcloud:widget:numtags' => 'Número de palavras a demonstrar',
	'tagcloud:site_cloud' => 'Núvem de palavras do site',
	'tagcloud:allsitetags' => 'Todos descritores (tags) do site',
);

<?php
return array(
	'tagcloud:widget:title' => 'Σύννεφο Ετικετών',
	'tagcloud:widget:description' => 'Σύννεφο ετικετών',
	'tagcloud:widget:numtags' => 'Αριθμός ετικετών για προβολή',
	'tagcloud:site_cloud' => 'Σύννεφο Ετικετών Ιστότοπου',
	'tagcloud:allsitetags' => 'Όλες οι ετικέτες',
);

<?php
return array(
	'tagcloud:widget:title' => 'وسم سحابي',
	'tagcloud:widget:description' => 'وسم سحابي',
	'tagcloud:widget:numtags' => 'إضهار عدد الوسوم السحابية',
	'tagcloud:site_cloud' => 'وسم سحابي للموقع',
	'tagcloud:allsitetags' => 'كل وسوم الموقع',
);

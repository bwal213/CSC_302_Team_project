<?php
return array(
	'tagcloud:widget:title' => '꼬리표 모음',
	'tagcloud:widget:description' => '꼬리표 모음',
	'tagcloud:widget:numtags' => '보여줄 꼬리표 수',
	'tagcloud:site_cloud' => '누리집 꼬리표 구름',
	'tagcloud:allsitetags' => '모든 꼬리표',
);

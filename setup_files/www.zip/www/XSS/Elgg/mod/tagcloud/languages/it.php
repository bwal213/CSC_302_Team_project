<?php
return array(
	'tagcloud:widget:title' => 'Nuvola di tag',
	'tagcloud:widget:description' => 'Nuvola di tag',
	'tagcloud:widget:numtags' => 'Numero di tag da mostrare',
	'tagcloud:site_cloud' => 'Nuvola di tag del sito',
	'tagcloud:allsitetags' => 'Tutte le tag del sito',
);

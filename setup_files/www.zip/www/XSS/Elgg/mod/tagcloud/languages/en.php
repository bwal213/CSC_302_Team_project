<?php
return array(
	'tagcloud:widget:title' => 'Tag Cloud',
	'tagcloud:widget:description' => 'Tag cloud',
	'tagcloud:widget:numtags' => 'Number of tags to show',
	'tagcloud:site_cloud' => 'Site Tag Cloud',
	'tagcloud:allsitetags' => 'All site tags',
);

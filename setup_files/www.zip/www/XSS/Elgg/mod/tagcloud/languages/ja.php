<?php
return array(
	'tagcloud:widget:title' => 'タグクラウド',
	'tagcloud:widget:description' => 'タグクラウド',
	'tagcloud:widget:numtags' => 'タグの表示数',
	'tagcloud:site_cloud' => 'タグクラウド',
	'tagcloud:allsitetags' => '全タグ',
);

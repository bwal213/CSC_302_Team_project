<?php
return array(	
	'custom:bookmarks' => "Најновији линкови",
	'custom:groups' => "Најновије групе",
	'custom:files' => "Најновији фајлови",
	'custom:blogs' => "Најновији блог чланци",
	'custom:members' => "Најновији чланови",
);

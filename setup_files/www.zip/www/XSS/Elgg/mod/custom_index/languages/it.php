<?php
return array(	
	'custom:bookmarks' => "Ultimi segnalibri",
	'custom:groups' => "Ultimi gruppi",
	'custom:files' => "Ultimi file",
	'custom:blogs' => "Ultimi articoli blog",
	'custom:members' => "Ultimi membri",
);

<?php
return array(	
	'custom:bookmarks' => "Ultimele marcaje",
	'custom:groups' => "Ultimele grupuri",
	'custom:files' => "Ultimele fișiere",
	'custom:blogs' => "Ultimele postări de blog",
	'custom:members' => "Cei mai noi membri",
);

<?php
return array(	
	'custom:bookmarks' => "Новые закладки",
	'custom:groups' => "Новые группы",
	'custom:files' => "Новые файлы",
	'custom:blogs' => "Новые посты в блогах",
	'custom:members' => "Новые пользователи",
);

<?php
return array(	
	'custom:bookmarks' => "Seneste bogmærker",
	'custom:groups' => "Seneste grupper",
	'custom:files' => "Seneste filer",
	'custom:blogs' => "Seneste blogindlæg",
	'custom:members' => "Seneste medlemmer",
);

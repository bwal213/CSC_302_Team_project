<?php
return array(	
	'custom:bookmarks' => "Najnowsze zakładki",
	'custom:groups' => "Najnowsze grupy",
	'custom:files' => "Najnowsze pliki",
	'custom:blogs' => "Najnowsze wpisy na blogu",
	'custom:members' => "Najnowsi użytkownicy",
);

<?php

return [
	'default' => [
		'notifications/' => __DIR__ . '/graphics',
	],
];

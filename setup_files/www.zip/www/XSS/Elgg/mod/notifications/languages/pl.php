<?php

return array(

	'friends:all' => 'Wszyscy znajomi',

	'notifications:subscriptions:personal:description' => 'Otrzymuj powiadomienia o akcjach wykonywanych na twojej treści',
	'notifications:subscriptions:personal:title' => 'Powiadomienia osobiste',

	'notifications:subscriptions:friends:title' => 'Znajomi',
	'notifications:subscriptions:friends:description' => 'Poniżej znajdują się kolekcje twoich znajomych. Wybór kolekcji włącza powiadomienia dla użytkowników w danej kolekcji.',
	'notifications:subscriptions:collections:edit' => 'Aby edytować swoje powiadomienia o dzielonym dostępie, kliknij tutaj.',

	'notifications:subscriptions:changesettings' => 'Powiadomienia',
	'notifications:subscriptions:changesettings:groups' => 'Powiadomienia grupowe',

	'notifications:subscriptions:title' => 'Powiadomienia o użytkowniku',
	'notifications:subscriptions:description' => 'Aby otrzymywać powiadomienia od twoich znajomych (indywidualnie) gdy tworzą nowe treści, znajdź ich poniżej i wybierz metodę powiadomień, której chcesz użyć.',

	'notifications:subscriptions:groups:description' => 'Aby otrzymywać powiadomienia o nowych treściach w grupach, do których należysz, znajdź daną grupę poniżej  i wybierz metodę(y) powiadomień, której chcesz użyć..',

	'notifications:subscriptions:success' => 'Twoje ustawienia powiadomień zostały zapisane.',

);

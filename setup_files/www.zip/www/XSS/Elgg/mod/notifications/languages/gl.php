<?php

return array(

	'friends:all' => 'Todos os contactos',

	'notifications:subscriptions:personal:description' => 'Recibir notificacións cando se realicen accións sobre os seus contidos.',
	'notifications:subscriptions:personal:title' => 'Notificacións persoais',

	'notifications:subscriptions:friends:title' => 'Contactos',
	'notifications:subscriptions:friends:description' => 'Embaixo ten coleccións dos seus contactos. Ao seleccionar unha colección actívanse as notificacións para os contactos desa colección.',
	'notifications:subscriptions:collections:edit' => 'Editar as notificacións de acceso compartid',

	'notifications:subscriptions:changesettings' => 'Notificacións',
	'notifications:subscriptions:changesettings:groups' => 'Notificacións de grupo',

	'notifications:subscriptions:title' => 'Notificacións por usuari',
	'notifications:subscriptions:description' => 'Para recibir notificacións dos seus contactos (de un en un) cando estes crean novo contido, localíceos a continuación e seleccione a forma de notificación que quere usar.',

	'notifications:subscriptions:groups:description' => 'Para recibir notificación cando se engada contido novo a un grupo do que vostede forma parte, localíceo a continuación e seleccione a forma de notificación que quere usar.',

	'notifications:subscriptions:success' => 'Gardouse a configuración de notificación.',

);

<?php

return array(

	'friends:all' => '所有朋友',

	'notifications:subscriptions:personal:description' => '當有動作施加於您的內容時就通知您',
	'notifications:subscriptions:personal:title' => '個人通知',

	'notifications:subscriptions:friends:title' => '朋友',
	'notifications:subscriptions:friends:description' => '以下是您的朋友集合。選取某個集合將會開啟對於該集合中使用者的通知。',
	'notifications:subscriptions:collections:edit' => '要編輯您共享的存取通知，請按一下這裡。',

	'notifications:subscriptions:changesettings' => '通知',
	'notifications:subscriptions:changesettings:groups' => '群組通知',

	'notifications:subscriptions:title' => '通知個別使用者',
	'notifications:subscriptions:description' => '當您個別的朋友建立新的內容時，如果要接收通知，就在以下尋找他們，並且選取您想要使用的通知方法。',

	'notifications:subscriptions:groups:description' => '當您所屬的群組加入新的內容時，如果您要接收通知，就在以下尋找它們，並且選取您想要使用的通知方法。',

	'notifications:subscriptions:success' => '您的通知設定值已儲存。',

);
